package com.example.sukhrana.rockpaperandroidproject;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class HomePageTableActivity extends AppCompatActivity {
    String[] myItems = {"Start Game", "Check Score", "Find Player", "Invite Friend"};
     int clickedRow = 7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page_table);
        ListView list =  (ListView) findViewById(R.id.listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, myItems);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedRow = myItems[position];
                clickedRow = position;
                Toast.makeText(HomePageTableActivity.this, String.format("%s was chosen.", selectedRow ),Toast.LENGTH_SHORT).show();
                 addList();

//                else if (position == 1){
//                    Intent i = new Intent(this,ShakingActivity.class);
//                    startActivity(i);
//                }
//                else if (position == 2){
//                    Intent i = new Intent(this, HomePageTableActivity.class);
//                    startActivity(i);
//                }
//                else if (position == 3){
//                    Intent i = new Intent(this, HomePageTableActivity.class);
//                    startActivity(i);
//                }
            }
        });


    }
    public void addList(){


        //ArrayAdapter<String> addData = new ArrayAdapter<String>(this,R.layout.activity_main, myItems);
        //ListView list =  (ListView) findViewById(R.id.listView);
        // ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.activity_main, myItems);
        //list.setAdapter(addData);
        Log.d("sukh", "done");


               if (clickedRow == 0){
                    Intent i = new Intent(this,ShakingActivity.class);
                    startActivity(i);
                }
                else if (clickedRow == 1){
                    Intent i = new Intent(this, Score.class);
                    startActivity(i);
                }
                else if (clickedRow == 2){
                    Intent i = new Intent(this, ShakingActivity.class);
                    startActivity(i);
                }
                else if (clickedRow == 3){
                    Intent i = new Intent(this, InviteFriendActivity.class);
                    startActivity(i);
                }

    }
}
