package com.example.sukhrana.rockpaperandroidproject;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.appinvite.AppInviteInvitation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;


public class InviteFriendActivity extends AppCompatActivity {

    // DEBUG variable
    //  public static final  TAG = "JENELLE";

    public static final int Request_Code = 100;

    // Outlets

    EditText usernameBox;
    EditText numberBox;
    EditText locationbox;


    // Firebase
    FirebaseFirestore db = FirebaseFirestore.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invite_friend);


        // setup the edittext outlet

        usernameBox = (EditText) findViewById(R.id.editText2);
        numberBox = (EditText) findViewById(R.id.editText3);
        locationbox = (EditText) findViewById(R.id.editText4);


    }


    public void addpressed(View v) {


        //
        //
        //  Log.d(TAG, "add pressed");

        Map<String, Object> player = new HashMap<>();
        player.put("first", "Ada");
        player.put("last", "Lovelace");
        player.put("born", 1815);


// Add a new document with a generated ID
        db.collection("Play")
                .add(player)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        // Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Log.w(TAG, "Error adding document", e);
                    }
                });


    }

    //    public void submitPressed(View v) {
//
//        // 0. disable the button
//        Button b = (Button) findViewById (R.id.submitButton);
//        b.setEnabled(false);
//
//
//        // 1. get user input
//        String name = usernameBox.getText().toString();
//        String numberInput = numberBox.getText().toString();
//
//        // 2. convert user input into a INTEGER
//        if (numberInput.isEmpty()) {
//            Log.d(TAG, "Number field is empty!");
//            return;
//        }
//
//        int num = Integer.parseInt(numberInput);
//
//        Log.d(TAG,"OKAY!!!!+++++=");
//
//
//
//        // 4. create a dictionary to store your data
//        // - We will be sending this dictionary to Firebase
//        Map<String, Object> player = new HashMap<>();
//        player.put("name", name);
//        player.put("choice", num);
//
//
//        //5. connect to firebase
//        // Add a new document with a ID = gameID
//
//        final DocumentReference ref = db.collection("games").document();
//        ref.set(player)
//           .addOnSuccessListener(new OnSuccessListener<Void>() {
//                @Override
//                public void onSuccess(Void aVoid) {
//                    Log.d(TAG, "Added player choice to game = " + ref.getId());
//                }
//            })
//            .addOnFailureListener(new OnFailureListener() {
//                @Override
//                public void onFailure(@NonNull Exception e) {
//                    Log.d(TAG, "Error adding document", e);
//                }
//            });
//
//
//
//
//
//    }
    public void invitePressed(View v) {

        Intent intent = new AppInviteInvitation.IntentBuilder("invitation title")
                .setMessage("hey there crazy app")
                .setDeepLink(Uri.parse("http://google.com"))
                .setCallToActionText("invitation_cta")
                .build();
        startActivityForResult(intent, Request_Code);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("santosh", "onActivityResult: requestCode=" + requestCode + ", resultCode=" + resultCode);

        if (requestCode == Request_Code) {
            if (resultCode == RESULT_OK) {
                // Get the invitation IDs of all sent messages
                String[] ids = AppInviteInvitation.getInvitationIds(resultCode, data);
                for (String id : ids) {
                    // Log.d(TAG, "onActivityResult: sent invitation " + id);

                    System.out.println("MainActivity.onActivityResult:"+ id);
                }
            } else {
                // Sending failed or it was canceled, show failure message to the user
                // ...
            }
        }
    }
    public void checkWinnerPressed(View v) {


        final TextView t = (TextView) findViewById(R.id.winnerLabel);
//
//        // get data from form
//        final String currentPlayer = usernameBox.getText().toString();
//        final int userInput = Integer.parseInt(numberBox.getText().toString());
        //Log.d(TAG, "get pressed");

        // get player choices from firebase
        //String path = "games/" + gameId;
        db.collection("Play")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            // Log.d(TAG,"finished querying firebase");
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                //Log.d(TAG, document.getId() + " => " + document.getData());

//                                String name = document.getData().get("name").toString();
//                                String choice = document.getData().get("choice").toString();


                                String name = document.getData().get("first").toString();
                                String choice = document.getData().get("last").toString();
                                String txttodiplay = ("the first is " + name) + ("the last is  is" + choice);
                                t.setText(txttodiplay);

//





//                                // calculate the winner
//                                if (name.equals(currentPlayer)) {
//                                    // this is the current player's choice, so skip it
//                                    Log.d(TAG, "Names are same, skipping");
//                                    t.setText("Waiting for other player choice...");
//
//                                    Log.d(TAG, "----------------");
//                                    continue;
//                                }
//                                else {
//                                    Log.d(TAG, "Names are different, calculating winner...");
//                                    String winner = "";
//                                    // compare user's choice with other player's choice
//                                    int player2Choice = Integer.parseInt(document.getData().get("choice").toString());
//
//                                    if (userInput > player2Choice) {
//                                        Log.d(TAG, "Winner is: " + currentPlayer);
//                                        t.setText("Winner is " + currentPlayer);
//                                    }
//                                    else if (userInput == player2Choice) {
//                                        Log.d(TAG, "TIE!");
//                                        t.setText("It's a tie!");
//                                    }
//                                    else {
//                                        Log.d(TAG, "Winner is: " + name);
//                                        t.setText("Winner is: " + name);
//                                    }
//
//                                    // After deciding a winner, enable the button again
//                                    Button b = (Button) findViewById(R.id.submitButton);
//                                    b.setEnabled(true);
//
//
//                                    Log.d(TAG, "Winner found,breaking!");
//                                    Log.d(TAG, "----------------");
//
//                                    break;
//                                }




                            }
                        } else {
                            //  Log.w(TAG, "Error getting documents.", task.getException());
                        }
                    }
                });





        // show the result in the textview





    }


}


